
<h1>Regras de associação</h1>
<h2 id = 'description'> Sobre</h2>

Regras de associação são algoritmos muito utilizados em Machine Learning. Trata-se de um algoritmo pertencente a classe de aprendizdo supervisionado.<br> 

Através do algoritmo de regras de associação é possível encontrar padrões relevantes dentro dos dados em um dataset. Com isso, é possível definir estratégias de negócios ou identificar um comportamento pouco usual. 

Esse projeto foi desenvolvido como demonstração desse algoritmo na prática. 

