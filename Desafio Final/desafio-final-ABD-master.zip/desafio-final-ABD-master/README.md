
<h1>Datasets utilizados no desafio final do curso de ABD</h1>
<h2 id = 'description'> Sobre</h2>

Esse repósitorio contém os datasets utilizados no desafio final do curso de Arquiteto(a) de Big Data.