Olá aluno(a), 

Sejam muito bem vindos! 

Esse repositório possui todos os arquivos e datasets utilizados nas vídeo aulas da disciplina de coleta e obtenção de dados. 

Um grande abraço e bons estudos! 